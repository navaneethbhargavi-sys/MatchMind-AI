# MatchMind AI

MatchMind AI is a synthetic football intelligence engine for a Premier League studio. It turns live, football-realistic events into tactical states, explainable narratives, multilingual fan copy, recaps and broadcast-ready overlays.

## Current demo

The local demo already proves the full experience with synthetic data:

- Live event ingestion over Server-Sent Events
- Replayable tactical scenarios: Pressure pulse, Rhythm control and Open match
- Derived possession, passing, pressure, tempo and territory metrics
- Tactical states: Control, Pressure, Chaos and Swing
- Evidence trails linked to source events
- Analyst and Fan narrative modes
- English, Spanish, French and Hindi output
- Insight library and recap timeline
- Lower-third, tactical-state and player-focus overlay previews
- Machine-readable graphics payloads
- Performance Lab with player thresholds, pass quality, speed metrics and simulated auto-eventing confidence
- Exportable synthetic match dataset with enriched event fields
- Cloud Pipeline view showing the Azure-ready architecture

## Run as a production server or container

The production server serves both the built React app and the API/SSE stream on port `8787`:

```bash
npm run build
npm start
```

With Docker available, run the same build as a container:

```bash
docker compose up --build
```

The container runs as the unprivileged Node user and checks `/api/health`.

On Windows, Docker Desktop's WSL 2 engine also needs the Virtual Machine Platform feature. If Docker reports that this feature is disabled, open Administrator PowerShell and run:

```powershell
Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform
```

Save your work and restart Windows to apply the feature. If WSL itself is not installed, run `wsl --install --no-distribution` from Administrator PowerShell and restart. Docker Desktop can be installed per-user after these Windows prerequisites are ready. The app can still be developed and previewed without Docker using the local steps below.

## Run locally

```bash
npm install
npm run dev
```

Open [http://127.0.0.1:4173/](http://127.0.0.1:4173/).

`npm run dev` starts both the React/Vite experience and the local synthetic event engine. The engine listens on port `8787`; Vite proxies `/api` requests to it.

## Architecture direction

The project is intentionally local-first for the hackathon demo, while keeping the data contracts cloud-ready:

| Stage | Current proof | Azure direction |
| --- | --- | --- |
| Ingest | Synthetic SSE event engine | Azure Event Hubs |
| Interpret | TypeScript replay metrics and tactical states | Azure Functions and Microsoft Fabric real-time analytics |
| Explain | Evidence-backed insight library | Microsoft Foundry with Azure AI Services |
| Persist | In-memory replay state | Azure Cosmos DB for match state, preferences and recap artifacts |
| Ground | Structured evidence rows | Azure AI Search for approved studio/player context |
| Render | React Overlay Lab and JSON payloads | Azure Container Apps APIs and broadcast integrations |
| Personalize | Analyst/Fan modes, player focus and four languages | Azure AI Services plus profile/preferences storage |
| Build | Versioned source | GitHub and GitHub Copilot workflow |

The `/api/platform/capabilities` endpoint exposes this service map for the UI and future deployment checks.

For the environment variables, single-container deployment shape and safe Azure handoff sequence, see [the Azure rollout guide](docs/azure-rollout.md).

The GitHub Actions workflow in `.github/workflows/publish-container.yml` builds and publishes `ghcr.io/<owner>/<repository>` on pushes to `main`. The repository must first be pushed to GitHub, and the GHCR package must be public before using the included Azure template. After installing Azure CLI, signing in, and choosing a subscription, deploy with:

```bash
az group create --name rg-matchmind-demo --location eastus
az deployment group create --resource-group rg-matchmind-demo --template-file infra/azure/main.bicep --parameters appName=matchmind-demo containerImage=ghcr.io/<owner>/<repository>:latest
```

Replace the image with your lowercase GitHub owner/repository path. The template creates a Log Analytics workspace and keeps one Container Apps replica warm, so Azure charges may continue while it is running. Review the region, logging and replica settings, and expected spend before deploying. The deployed app remains synthetic-only; cloud integrations are not active just because the hosting is in Azure.

## Demo story for judging

1. Start in Live Studio and show the event stream moving.
2. Switch replay scenarios to show that different event patterns create different tactical stories.
3. Select an evidence row and show the linked source-event trail.
4. Open Insights to show explainability and confidence.
5. Open Recaps and switch between Analyst, Fan and Spanish output.
6. Open Overlay Lab and take a tactical insight on air.
7. Finish on Cloud Pipeline to explain the path to Azure Event Hubs, Functions, Foundry, Fabric and Cosmos DB.

## Verification

```bash
npm run build
```

The build runs TypeScript checks and produces the Vite production bundle.
