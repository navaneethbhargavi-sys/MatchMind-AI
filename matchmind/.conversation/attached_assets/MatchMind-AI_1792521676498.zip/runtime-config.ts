export type IntegrationState = "local" | "configured" | "ready";

function hasValue(value: string | undefined) {
  return Boolean(value && value.trim());
}

function integration(state: IntegrationState, detail: string) {
  return { state, detail };
}

export function getRuntimeConfig() {
  const eventHubConfigured = hasValue(process.env.AZURE_EVENT_HUBS_CONNECTION_STRING) && hasValue(process.env.AZURE_EVENT_HUB_NAME);
  const foundryConfigured = hasValue(process.env.AZURE_OPENAI_ENDPOINT) && hasValue(process.env.AZURE_OPENAI_DEPLOYMENT) && (hasValue(process.env.AZURE_OPENAI_API_KEY) || hasValue(process.env.AZURE_CLIENT_ID));
  const cosmosConfigured = hasValue(process.env.AZURE_COSMOS_ENDPOINT) && (hasValue(process.env.AZURE_COSMOS_KEY) || hasValue(process.env.AZURE_CLIENT_ID));
  const fabricConfigured = hasValue(process.env.FABRIC_WORKSPACE_ID);

  return {
    host: process.env.HOST || "127.0.0.1",
    port: Number(process.env.PORT || 8787),
    runtime: process.env.MATCHMIND_RUNTIME || "local",
    syntheticOnly: true,
    integrations: {
      eventHubs: eventHubConfigured ? integration("configured", "Credentials detected; synthetic stream remains active until the Event Hubs adapter is enabled.") : integration("ready", "Set AZURE_EVENT_HUBS_CONNECTION_STRING and AZURE_EVENT_HUB_NAME to enable the adapter."),
      foundry: foundryConfigured ? integration("configured", "Foundry/Azure OpenAI configuration detected; deterministic grounded narratives remain active by default.") : integration("ready", "Set Azure OpenAI or managed identity settings to enable the narrative adapter."),
      cosmos: cosmosConfigured ? integration("configured", "Cosmos DB configuration detected; in-memory replay state remains active by default.") : integration("ready", "Set Cosmos endpoint and identity/key settings to persist match state."),
      fabric: fabricConfigured ? integration("configured", "Fabric workspace configuration detected; analytics export adapter can be enabled.") : integration("ready", "Set FABRIC_WORKSPACE_ID when the analytics workspace is available."),
    },
  };
}
