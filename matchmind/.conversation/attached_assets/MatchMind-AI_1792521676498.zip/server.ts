import { createServer, type ServerResponse } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, isAbsolute, join, relative, resolve } from "node:path";
import { getSnapshot, initialEvents, nextEvent, replayScenarios, type MatchEvent, type ReplayScenario } from "./src/data.ts";
import { platformServices, platformStages } from "./src/platform.ts";
import { getRuntimeConfig } from "./runtime-config.ts";

const runtimeConfig = getRuntimeConfig();
const port = runtimeConfig.port;
const host = runtimeConfig.host;
let cursor = 0;
let scenario: ReplayScenario = "pressure-pulse";
let events: MatchEvent[] = [...initialEvents];
const clients = new Set<ServerResponse>();

function payload() {
  return { cursor, scenario, event: events.at(-1), events, snapshot: getSnapshot(cursor, scenario) };
}

function isScenario(value: string | null): value is ReplayScenario {
  return replayScenarios.some((item) => item.id === value);
}

function writeJson(response: ServerResponse, value: unknown, status = 200) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(JSON.stringify(value));
}

const contentTypes: Record<string, string> = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
};

async function serveStatic(response: ServerResponse, pathname: string) {
  const distDirectory = join(process.cwd(), "dist");
  const requestedFile = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const resolvedPath = resolve(distDirectory, requestedFile);
  const relativePath = relative(distDirectory, resolvedPath);
  const safePath = relativePath && !relativePath.startsWith("..") && !isAbsolute(relativePath)
    ? resolvedPath
    : join(distDirectory, "index.html");

  try {
    const content = await readFile(safePath);
    response.writeHead(200, { "Content-Type": contentTypes[extname(safePath)] || "application/octet-stream", "Cache-Control": "public, max-age=3600" });
    response.end(content);
  } catch {
    try {
      const index = await readFile(join(distDirectory, "index.html"));
      response.writeHead(200, { "Content-Type": contentTypes[".html"], "Cache-Control": "no-store" });
      response.end(index);
    } catch {
      writeJson(response, { error: "Not found" }, 404);
    }
  }
}

function sendStream(response: ServerResponse) {
  response.write(`data: ${JSON.stringify(payload())}\n\n`);
}

function advanceReplay() {
  cursor += 1;
  const event = nextEvent(cursor, getSnapshot(cursor, scenario).clock, scenario);
  events = [...events, event].slice(-9);
  for (const client of clients) {
    try { sendStream(client); } catch { clients.delete(client); }
  }
}

setInterval(advanceReplay, 1800);

const server = createServer(async (request, response) => {
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);

  if (url.pathname === "/api/health") {
    writeJson(response, { ok: true, service: "matchmind-event-engine", mode: "synthetic", runtime: runtimeConfig.runtime, syntheticOnly: runtimeConfig.syntheticOnly });
    return;
  }
  if (url.pathname === "/api/ready") {
    writeJson(response, { ready: true, service: "matchmind-event-engine", integrations: runtimeConfig.integrations });
    return;
  }
  if (url.pathname === "/api/matches/match-001") {
    writeJson(response, payload());
    return;
  }
  if (url.pathname === "/api/matches/match-001/dataset") {
    writeJson(response, {
      source: "synthetic-football-realistic",
      matchId: "match-001",
      scenario,
      events,
      snapshot: getSnapshot(cursor, scenario),
      schema: ["playerId", "eventType", "zone", "distanceM", "speedKph", "ballSpeedKph", "shotSpeedKph", "passAccuracy", "passDifficulty", "modelConfidence"],
    });
    return;
  }
  if (url.pathname === "/api/replay/scenarios") {
    writeJson(response, { scenarios: replayScenarios, selected: scenario });
    return;
  }
  if (url.pathname === "/api/platform/capabilities") {
    writeJson(response, {
      mode: "synthetic-local",
      stream: "sse",
      stages: platformStages,
      services: platformServices,
      integrations: runtimeConfig.integrations,
      contractVersion: "0.3",
    });
    return;
  }
  if (url.pathname === "/api/matches/match-001/events/stream") {
    response.writeHead(200, { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-store", Connection: "keep-alive", "Access-Control-Allow-Origin": "*" });
    clients.add(response);
    sendStream(response);
    request.on("close", () => clients.delete(response));
    return;
  }
  if (url.pathname === "/api/replay/reset" && request.method === "POST") {
    const requestedScenario = url.searchParams.get("scenario");
    if (isScenario(requestedScenario)) scenario = requestedScenario;
    cursor = 0;
    events = [...initialEvents];
    for (const client of clients) sendStream(client);
    writeJson(response, payload());
    return;
  }
  if (!url.pathname.startsWith("/api/")) {
    await serveStatic(response, url.pathname);
    return;
  }
  writeJson(response, { error: "Not found" }, 404);
});

server.listen(port, host, () => {
  console.log(`[matchmind] synthetic event engine listening on http://${host}:${port}`);
});
