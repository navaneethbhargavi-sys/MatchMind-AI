# Azure rollout guide

MatchMind AI is deliberately runnable with no cloud account or credentials. The local engine remains synthetic-only for the hackathon demo. This guide describes the handoff from the local contract to Azure services when the subscription and credentials are available.

## What already works locally

- Synthetic events stream through SSE.
- Replay scenarios produce changing tactical states, evidence and recaps.
- The app exposes `/api/health`, `/api/ready`, `/api/platform/capabilities` and a synthetic dataset endpoint.
- The same Node server can serve the production `dist/` bundle, so it can run as one container.

## Azure service mapping

| Need | Azure service | Adapter responsibility |
| --- | --- | --- |
| Live synthetic events | Azure Event Hubs | Consume match events and preserve the current event contract. |
| Stateful aggregation | Azure Functions | Create time-window metrics, states and threshold triggers. |
| Tactical analytics | Microsoft Fabric | Store event history and calculate larger real-time/post-match views. |
| Narrative agent | Microsoft Foundry / Azure OpenAI | Produce audience- and language-specific copy grounded in evidence IDs. |
| Translation | Azure AI Services | Extend language coverage while retaining the source evidence. |
| Match and preference state | Azure Cosmos DB | Persist replay snapshots, favorite clubs, favorite players and recaps. |
| Studio context retrieval | Azure AI Search | Retrieve approved editorial/player context for grounded narratives. |
| API and UI hosting | Azure Container Apps | Run the container image with health checks and environment settings. |

## Configuration boundary

Copy `.env.example` to `.env` only when you have your own Azure configuration. Never commit the copied file or credentials.

The local server checks configuration presence without returning secrets:

- `GET /api/health` reports the active local runtime.
- `GET /api/ready` reports whether each cloud adapter has configuration.
- `GET /api/platform/capabilities` exposes the service map used by the Cloud Pipeline view.

This makes it safe to demo locally while showing judges exactly what changes when cloud resources are provisioned.

## Container deployment shape

1. Build the image with the included `Dockerfile`.
2. Push it to a container registry available to the Azure Container Apps environment.
3. Create one Container App from the image, expose port `8787`, and configure an HTTP health probe against `/api/health`.
4. Add non-secret runtime settings such as `MATCHMIND_RUNTIME=azure`.
5. Add Event Hubs, Foundry/Azure OpenAI, Cosmos DB and Fabric settings through the platform’s secret/configuration mechanism or managed identity.
6. Enable each adapter only after its credentials and least-privilege access have been verified.

The included `infra/azure/main.bicep` provisions a Container Apps environment, Log Analytics workspace and one externally reachable app revision. It expects a public GHCR image and defaults the runtime to `local` so the UI does not imply that unimplemented cloud adapters are active. After the image is published and you have reviewed Azure costs, deploy it with Azure CLI:

```bash
az login
az account set --subscription <subscription-id>
az group create --name rg-matchmind-demo --location eastus
az deployment group create --resource-group rg-matchmind-demo --template-file infra/azure/main.bicep --parameters appName=matchmind-demo containerImage=ghcr.io/<owner>/<repository>:latest
```

The template keeps one replica warm and creates a Log Analytics workspace; both settings can incur ongoing charges. Delete the dedicated resource group after the demo if you no longer need it:

```bash
az group delete --name rg-matchmind-demo --yes --no-wait
```

Only use that cleanup command for this dedicated demo resource group after confirming it contains no resources you want to keep.

## Demo-safe operating mode

Keep `MATCHMIND_RUNTIME=local` and the Azure values empty during the hackathon demo unless an Azure resource is genuinely connected. The UI will remain fully functional and the Cloud Pipeline view will accurately label services as cloud-ready rather than live.

## Suggested next implementation order

1. Event Hubs consumer adapter that emits the existing SSE payload shape.
2. Foundry narrative adapter that returns structured JSON: headline, narrative, confidence and evidence IDs.
3. Cosmos DB storage for replay state and audience preferences.
4. Fabric export for post-match analytics and evaluation data.
